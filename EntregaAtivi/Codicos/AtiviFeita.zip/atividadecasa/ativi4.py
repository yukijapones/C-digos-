idade  = [10,5,7,9,12]
print (idade)

soma = 0 
quantidade = 0 

for i in idade:
    soma += 1 
    quantidade += 1 
resultado = soma / quantidade
print ("A media das idades é:   ", resultado)



