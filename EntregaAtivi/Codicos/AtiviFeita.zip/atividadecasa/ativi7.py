quantidade = 0
soma = 0

for i in range(1,51):
    if i % 2 == 0:
        quantidade += 1 
        soma += i 
    

print("A quantidade de numeros pares sao:   ", quantidade)
print("A soma da quantidade de numeros pares é: ", soma)
    